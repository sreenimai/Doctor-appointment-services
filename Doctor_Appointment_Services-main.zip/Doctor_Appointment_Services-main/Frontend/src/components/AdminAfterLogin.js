//STEP 1 -- IMPORT REACT
import React from 'react'
import Navbar from './Navbar'
import '../css/Home.css';
//STEP 2 -- CREATE FUNCTIONAL COMPONENT
function AdminAfterLogin() {
    return (
        <>
        <div id="App185">
        <div>
        <Navbar/>
        </div>
        </div>
        </>)
}

//STEP 3 -- EXPORT IT TO USE IT
export default AdminAfterLogin