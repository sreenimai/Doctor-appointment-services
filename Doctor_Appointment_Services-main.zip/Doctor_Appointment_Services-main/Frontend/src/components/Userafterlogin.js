import React from "react";
import Navbar from "./Navbar";
import '../css/Userloginafter.css';
function UserAfterLogin()
{
    return( 
   <div className="Login123">
   <Navbar/>
    
    </div> 
    )
}
export default UserAfterLogin